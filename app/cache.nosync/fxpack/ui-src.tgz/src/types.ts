export interface Game {
  bye: boolean;
  opp?: string;
  home?: boolean;
  day?: string;
  date?: string;
  time?: string;
  implied_total?: number | null;
  game_total?: number | null;
}

export type Pos = "QB" | "RB" | "WR" | "TE" | "K" | "DST";

export interface Player {
  id: number;
  name: string;
  pos: Pos;
  team: string | null;
  headshot: string | null;
  slot: string;
  injury: string;
  espn_week: number | null;
  week_range: [number, number] | null;
  est_ppg: number | null;
  avail_now: number | null;
  avail_ros: number | null;
  ecr_rank: number | null;
  status: string | null;
  bye: number | null;
  game: Game | null;
  weekly: (number | null)[];
  ppg: number | null;
  games: number;
}

export interface OppStarter {
  id: number;
  name: string;
  pos: Pos;
  team: string | null;
  headshot: string | null;
  espn_week: number | null;
  slot: string;
  game: Game | null;
  injury: string;
}

export interface Matchup {
  opp_id: number;
  opp_name: string;
  my_proj: number;
  opp_proj: number;
  p_win: number;
  margin_sd: number;
  opp_starters: OppStarter[];
}

export interface TeamWeek {
  season: number;
  week: number;
  team_id: number;
  team_name: string;
  players: Player[];
  lineup: {
    current: Record<string, number>;
    suggested: Record<string, number>;
    current_pts: number;
    suggested_pts: number;
    swaps: { start: string; bench: string; gain: number }[];
  };
  matchup: Matchup | null;
  notes: Record<string, string>;
}

export interface Odds { seed1: number | null; top2: number | null; playoffs: number | null; title: number | null }

export interface PowerTeam {
  id: number;
  name: string;
  record: { w: number; l: number; t: number; pa: number };
  pf: number;
  pa: number;
  weekly: number[];
  weekly_proj: (number | null)[];
  proj_pf: number | null;
  luck: number | null;
  ros_value: number | null;
  proj_final_pts: number | null;
  odds: Odds | null;
  odds_history: ({ week: number } & Odds)[];
  pf_rank: number;
  proj_rank: number;
}

export interface Power {
  season: number;
  through_week: number;
  weeks_played: number;
  odds_as_of_week: number;
  teams: PowerTeam[];
  notes: Record<string, string>;
}

export interface Snapshot {
  generated_at: number;
  season: number;
  week: number;
  data_age: Record<string, number | null>;
  team_week: TeamWeek;
  power: Power;
  /** per-position quantiles of actual/forecast points, used for head-to-head odds */
  ratio_q?: Record<string, number[]>;
  team_colors?: Record<string, { name: string; color: string; alt: string }>;
  engine_version?: number;
}

export interface LiveOdds { seed1: number; top2: number; playoffs: number; title: number; reg_pts: number }
export interface RosterRow { id: number; name: string; pos: Pos; est_ppg: number | null; avail: number | null; status: string; ir: boolean; headshot: string | null; team?: string | null }
export interface LeagueAnalysis {
  weeks: number[]; positions: Pos[]; reg_end: number; playoff_teams: number;
  seed_dist: Record<string, number[]>; week_pts: Record<string, number[]>;
  pos_ppw: Record<string, Record<string, number>>; stream_rate: Record<string, Record<string, number>>;
  pos_so_far: Record<string, Record<string, number>>;
}
export interface LeagueLive { sims: number; week: number; odds: Record<string, LiveOdds>; rosters: Record<string, RosterRow[]>; noise_pp: number; analysis?: LeagueAnalysis }
export interface WhatIfResult { sims: number; base: Record<string, LiveOdds>; scenario: Record<string, LiveOdds>; delta: Record<string, LiveOdds>; noise_pp: number }
export interface OutItem { id: number; weeks: number | null; name: string; team: number }

export interface TradeSide {
  name: string; gives: string[]; gets: string[]; would_drop: string[];
  delta_regular_season: number; delta_playoffs: number; delta_total: number; delta_total_calibrated: number;
  p_direction_right: number; edge_label: string; why: Record<string, string>;
}
export interface TradeEval { model: { week: number; teams: Record<string, TradeSide> }; espn: { week: number; teams: Record<string, TradeSide> } }
export interface TradeOdds { sims: number; noise_pp: number; teams: Record<string, { before: LiveOdds; after: LiveOdds; delta: LiveOdds }> }
export interface TradeHistory { sent: number; accepted: number; declined: number; canceled: number }
export interface IdeaRow {
  with: string; give: string; get: string; you_drop: string; your_gain: number; your_gain_calibrated: number;
  your_gain_playoffs: number; p_right: number; their_gain: number; trust: string; partner: number; give_ids: number[]; get_ids: number[];
}
export interface IdeasState { state: "idle" | "running" | "done" | "failed"; partner: number | null; started: number | null; rows: IdeaRow[]; error: string | null }

export interface Usage { weeks: number[]; targets: (number | null)[]; carries: (number | null)[]; target_share: (number | null)[]; snap_pct: (number | null)[] }
export interface WaiverRow {
  id: number; name: string; pos: Pos; team: string | null; headshot: string | null;
  espn_wk: number | null; est_ppg: number | null; avail: number | null; ros: number | null; ecr_rank: number | null;
  tag: string; why: string; gain: number | null; drop_id: number | null; drop_name: string | null; usage: Usage | null;
}
export interface DepthRow { id: number; name: string; est_ppg: number | null; avail: number | null; ir: boolean; team: string | null; usage: Usage | null; drop_cost?: number | null; kept?: boolean }
export interface WaiverBoard {
  week: number; candidates: WaiverRow[]; depth: Record<string, DepthRow[]>; replacement: Record<string, number>;
  left_off: { id: number; name: string; pos: Pos; tag: string; est_ppg: number | null }[]; noise: number;
  /** season lineup points lost without each of your players (engine v3) */
  drop_cost?: Record<string, number>; pool_size?: Record<string, number>; computed_at?: number;
  /** ids of your players you won't drop (saved by the engine; the drop search skips them) */
  keep?: number[];
}

export type JKind = "lineup" | "waiver" | "trade" | "note";
export type JStatus = "done" | "offered" | "skipped";
export interface JOutcome {
  state: "pending" | "final" | "running" | "none";
  start_pts?: number; bench_pts?: number; right?: boolean; weeks?: [number, number]; in_pts?: number; out_pts?: number;
}
export interface JEntry {
  id: string; created_at: number; week: number; kind: JKind; title: string; why: string; confidence: number | null;
  payload: Record<string, unknown>; model: Record<string, unknown>; model_p: number | null; status: JStatus; outcome: JOutcome;
}
export interface JSummary {
  logged: number; resolved: number; hit_rate: number | null; your_conf: number | null; model_p: number | null;
  buckets: { lo: number; hi: number; n: number; hit: number | null }[];
}
export interface Journal { entries: JEntry[]; summary: JSummary; week: number }
export interface JDraft {
  kind: JKind; title: string; why?: string; confidence?: number | null; payload?: Record<string, unknown>;
  model?: Record<string, unknown>; model_p?: number | null; week?: number; status?: JStatus;
  /** shown in the log sheet, not stored */
  context?: string;
}

export interface RoleTrait { label: string; text: string; pct: number; side: "hi" | "lo"; key?: string; rel?: number }
export interface RoleTrend {
  kind: string; label: string; text: string; hold: number | null; hold_n?: number; cause?: string[]; hold_if_still_out?: number | null;
  next_vs_espn?: number | null; next_lo?: number | null; next_hi?: number | null; next_n?: number; season?: boolean;
}
export interface RoleStyle { name: string; p: number; alt: string; alt_p: number; probs: Record<string, number>; from_last_season?: boolean }
export interface RoleProfile {
  name: string; pos: Pos; team: string | null; games: number; tier: string;
  style: RoleStyle | null; traits: RoleTrait[]; trends: RoleTrend[];
  series: { weeks: number[]; snap: number[]; share: (number | null)[]; rz: (number | null)[]; share_label: string } | null;
}
export interface RolesBoard {
  season: number; through_week: number; fit_seasons: [number, number];
  styles: Record<string, { names: string[]; yoy_same: number; early_acc?: Record<string, { acc: number; conf: number; n: number }> }>;
  players: Record<string, RoleProfile>;
}

export interface FpMetric {
  key: string; label: string; fmt: "pct" | "pct100" | "num1" | "num2"; group: "Role" | "Style" | "Scoring" | "Efficiency";
  raw: number | null; est: number; prev: number | null; pct: number | null; raw_pct: number | null; rel: number; stab_games: number; lower_better: boolean; rank?: number; of?: number;
}
export interface MapGroup { name: string; x: number; y: number; cov: [[number, number], [number, number]] }
export interface MapPeer { id: number | null; x: number; y: number; vol: number | null; name: string | null; owner: { team_id: number; name: string } | null }
export interface LogRow {
  week: number; played: boolean; upcoming: boolean; opp: string | null; snap: number | null; tgt: number | null; rec: number | null; rec_yd: number | null; rec_td: number | null;
  car: number | null; rush_yd: number | null; rush_td: number | null; cmp: number | null; att: number | null; pass_yd: number | null; pass_td: number | null;
  ints: number | null; fl: number | null; ppr: number | null; espn_pts: number | null; espn_proj: number | null;
}
export interface CompRow {
  name: string; season: number; team: string; sim: number; ppg_then: number; snap_then: number; share_then: number | null; age: number | null;
  prev_ppg: number | null; ros_ppg: number; ros_games: number; ros_team_games: number; ros_snap: number | null; traj: (number | null)[];
}
export interface Comps {
  W: number; k: number; pool: number; q: { p10: number; p25: number; p50: number; p75: number; p90: number };
  avail: number; kept_role: number; beat_now: number; weeks: { n: number; q: number[]; ge15: number; lt5: number; hist: number[] };
  dist_ppg: number[]; list: CompRow[]; all: { name: string; season: number; ros_ppg: number; ppg_then: number }[];
  me: { ppg: number; age: number | null; exp: number | null; prev_ppg: number | null };
  bt: { mae: number; mae_sofar: number; mae_lin: number; cov80: number; cov50: number; rho: number; n: number } | null; starter_ppg: number | null;
}
export interface PlayerFile {
  id: number; name: string; pos: Pos; team: string | null; pro_team?: string | null; headshot?: string | null; season: number; through_week: number; week: number;
  age: number | null; draft: { year: number; round: number | null; pick: number | null } | null;
  owner: { team_id: number; name: string; injury?: string | null } | null;
  ledger: { est_ppg: number | null; avail_now: number | null; avail_ros: number | null; ecr_rank: number | null; status: string | null; bye: number | null } | null;
  espn_week: number | null; game?: { bye: boolean; home?: boolean; opp?: string; day?: string; time?: string } | null;
  season_line: { games: number; ppr_g: number; snap: number; espn_g: number | null; rank: number | null; of: number } | null;
  last_season: { games: number; ppr_g: number; snap: number } | null;
  role: RoleProfile; fingerprint: FpMetric[];
  style_info: { names: string[]; centroids: Record<string, Record<string, number>>; transitions: Record<string, Record<string, number>>;
    meaning: Record<string, { ppg: number; n: number; snap: number }>; early_acc: Record<string, { acc: number; conf: number; n: number }>; yoy_same: number; kappa: number };
  map: { x: string; y: string; xlabel: string; ylabel: string; groups: MapGroup[]; peers: MapPeer[]; trail: { week: number; x: number; y: number }[];
    last_season: { x: number; y: number } | null; fmt: Record<string, string> };
  gamelog: LogRow[]; comps: Comps | null;
  read: { kind: "role" | "signal" | "caution" | "change" | "outlook"; anchor: string; text: string }[];
}

export interface ShiftWin {
  from_snap: number | null; to_snap: number | null; from_share: number | null; to_share: number | null; label: string;
  d_snap: number | null; d_share: number | null; zone: string | null; hold?: number | null; hold_if_still_out?: number | null;
  cause?: string[]; espn?: { rel: number; lo: number; hi: number } | null;
}
export interface ShiftRow {
  id: number; name: string; pos: Pos; team: string | null; headshot: string | null; owner: { team_id: number; name: string; injury?: string | null } | null;
  games: number; tier: string; style: string | null; series: { weeks: number[]; snap: number[]; share: (number | null)[]; share_label: string };
  recent: ShiftWin | null; season: ShiftWin | null; ledger: { est_ppg: number | null; avail: number | null; status: string | null } | null;
  espn_week: number | null; injury: string | null;
}
export interface Shifts {
  season: number; through_week: number; week: number; rows: ShiftRow[];
  zones: Record<string, Record<string, { hold: number | null; n: number | null; espn?: { rel: number; lo: number; hi: number } | null }> & { season: Record<string, { hold: number; n: number }> }>;
  thresholds: { snap: number; share: number; snap_with: number };
}
